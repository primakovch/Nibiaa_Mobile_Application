import 'package:thingsboard_pe_client/thingsboard_client.dart';

TbStorage createAppStorage() => throw UnsupportedError('');
